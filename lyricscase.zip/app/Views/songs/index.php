<?= $this->extend('layouts/base_layout'); ?>

<?= $this->section('content'); ?>

<div class="container my-3">
    <?php foreach ($songs as $song) : ?>
        <a class="text-decoration-none text-info-emphasis" href="<?= base_url('songs/' . esc($song['song_id'])); ?>">
            <div class="bg-body rounded-4 shadow-sm fw-medium px-3 mb-2 p-2">
                <img class="me-2" src="<?= esc($song['song_artwork']); ?>" width="50px">
                <span><?= esc($song['artist_names']); ?> - <?= esc($song['song_title']); ?> lyrics</span>
            </div>
        </a>
    <?php endforeach ?>
</div>

<?= $this->endSection(); ?>
