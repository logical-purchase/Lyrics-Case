<?php

namespace App\Controllers;
use App\Models\UserModel;

class Home extends BaseController
{
    public function index(): string
    {
        $userModel = new UserModel();
        $loggedUserId = session()->get('loggedUser');
        $userInfo = $userModel->find($loggedUserId);
        
        $data = [
            'title'    => 'Lyrics Case',
            'userInfo' => $userInfo
        ];
        return view('songs/index', $data);
    }
}
